# Assignment 01

In the following, you find the list of groups that we recommend you work in for the first mandatory assignment.
In case you are not able to work in your group, contact your suggested team members below (either in person, via email, or via Discord) to discuss your constraints and plans with them.

If you switch to another group, send a pull request to this file that indicates your new group setup.


* Group 1: mroa, atro, mesv
* Group 2: midf, jevb, stmp
* Group 3: nidd, tosp, rakt
* Group 4: mhvl, noms, mlth
* Group 5: jacg, maxt, vime
* Group 6: luel, malsc, laup
* Group 7: seel, ntro, 
* Group 8: nkrj, ahad, mbln
* Group 9: brml, nicha, mhsi
* Group 10: eikb, bemi, dadh
* Group 11: lufr, rasni, mfjo
* Group 12: adjr, teim, olfw
* Group 13: mbia, shho, clly
* Group 14: jouj, fefa, hecn
* Group 15: kmsa, omac, biha
* Group 16: hcan, vist, bjhh
* Group 17: nihp, ojoh, mreh
* Group 18: nsel, paab, oska
* Group 19: hast, pekp, tbru
* Group 20: tuho, phimo, rogy
* Group 21: ivil, asgm, frjo
* Group 22: bath, ehel, jakst
* Group 23: reer, aarv, lanr
* Group 24: luha, base, chbl
* Group 25: avia, remy, selb
* Group 26: kbej, dlha, elbr
* Group 27: raoo, annro, aegr
* Group 28: diol, kays, emno
* Group 29: husa, frepe, adrka
* Group 30: json, clwj, emkh
* Group 31: jwni, rafa, otja
* Group 32: lawu, frgm, tuka
* Group 33: wihe, oljh, okre
* Group 34: aguh, erja, mgan
//* Group 35: shad, brat, millh
* Group 36: asjo, aldy, skas
* Group 37: aing, memr, phla
* Group 38: behv, tokj, jsev
* Group 39: tbav, nlje, gues
* Group 40: tcla, siol, siar
* Group 41: sibh, crco, kmey
* Group 42: stmp, tael
* Group 43: emtj, jklo, mwha
* Group 44: monha, ssbo, timj
* Group 45: labp, jric, laku
* Group 46: amdh, frai, weny
* Group 47: Emno, frhc, bhag
* Group 48: unla, asly, mbjn
