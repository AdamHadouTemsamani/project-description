global using Xunit;
global using FluentAssertions;
global using System.Text.RegularExpressions;